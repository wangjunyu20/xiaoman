---
name: cailianshe-news
description: Fetch real-time financial news from Cailianshe (财联社), a mainstream Chinese financial news agency. Use this skill when users need to retrieve financial telegraph news, industry-specific news, or real-time market updates from Cailianshe.
---

# Cailianshe News Fetcher

This skill provides the ability to fetch real-time financial news from **Cailianshe (财联社)**, one of China's mainstream financial news agencies.

## When to Use

Use this skill when:
- Users need to fetch real-time financial news from Cailianshe
- Users need industry-specific news (e.g., AI, semiconductors, robotics)
- Users need financial telegraph updates for investment research

## How to Use

### Method 1: Use the Python Script Directly

Execute the script with keyword and optional limit:

```bash
python scripts/fetch_cailianshe.py <keyword> [limit]
```

Examples:
```bash
# Fetch 3 news items about "光模块" (optical modules)
python scripts/fetch_cailianshe.py "光模块" 3

# Fetch 5 news items about "人形机器人" (humanoid robots)
python scripts/fetch_cailianshe.py "人形机器人" 5
```

### Method 2: Import as Python Module

```python
from scripts.fetch_cailianshe import CailiansheNewsFetcher, fetch_cailianshe_news

# Method A: Use the convenience function
news = fetch_cailianshe_news("光模块", limit=5)

# Method B: Use the class for more control
fetcher = CailiansheNewsFetcher(cache_dir="./cache", cache_ttl=1800)
news = fetcher.fetch_telegraph("AI应用", limit=3)

# Process results
for item in news:
    print(f"Title: {item['title']}")
    print(f"URL: {item['url']}")
    print(f"Time: {item['publish_time']}")
    print(f"Impact: {item['impact']}")
    print(f"Summary: {item['summary']}")
```

## News Data Structure

Each news item returned is a dictionary with:

| Field | Type | Description |
|-------|------|-------------|
| `source` | str | News source (always "财联社") |
| `title` | str | News headline |
| `url` | str | Full URL to the original article |
| `publish_time` | str | Publication time (format: YYYY-MM-DD HH:MM) |
| `summary` | str | Brief summary of the content |
| `impact` | str | Sentiment analysis: "利好" (positive), "利空" (negative), or "中性" (neutral) |

## Technical Details

### API Endpoint
```
https://www.cls.cn/nodeapi/telegraphList
```

This is a **signature-free API** that returns JSON data directly.

### Request Parameters
- `app`: CailianpressWeb
- `os`: web
- `sv`: 8.4.6
- `rn`: 50 (number of results)
- `last_time`: 0 (timestamp for pagination)

### URL Format
Article URLs follow the pattern:
```
https://www.cls.cn/telegraph/{id}
```

### Caching
- Default cache directory: `./news_cache/`
- Default cache TTL: 30 minutes (1800 seconds)
- Cache files are stored as JSON

### Supported Industries
The following industries have pre-configured keyword mappings:

- 光模块 (Optical Modules)
- 人形机器人 (Humanoid Robots)
- 量子科技 (Quantum Technology)
- AI应用 (AI Applications)
- 脑机接口 (Brain-Computer Interface)
- 可控核聚变 (Nuclear Fusion)
- AI+医疗 (AI Healthcare)
- 消费 (Consumption)
- 集成电路 (Integrated Circuits)
- 低空经济 (Low-altitude Economy)
- 算力 (Computing Power)

## Examples

### Example 1: Fetch News for Semiconductor Industry
```python
from scripts.fetch_cailianshe import fetch_cailianshe_news

news = fetch_cailianshe_news("集成电路", limit=3)
for item in news:
    print(f"[{item['impact']}] {item['title']}")
    print(f"   → {item['url']}\n")
```

### Example 2: Command Line Usage
```bash
# Get latest AI industry news
python scripts/fetch_cailianshe.py "AI应用" 5
```

### Example 3: Batch Fetch Multiple Industries
```python
from scripts.fetch_cailianshe import CailiansheNewsFetcher

fetcher = CailiansheNewsFetcher()
industries = ["光模块", "人形机器人", "量子科技"]

for industry in industries:
    news = fetcher.fetch_telegraph(industry, limit=3)
    print(f"\n=== {industry} ({len(news)}条) ===")
    for item in news:
        print(f"• {item['title'][:40]}...")
```

## Notes

- The API returns the latest 50 telegraph messages, which are then filtered by keyword
- If no matching news is found for a keyword, an empty list is returned
- The API has rate limiting; use caching to avoid being blocked
- All URLs are complete and clickable (unlike some other news sources that return relative paths)

## Error Handling

The script handles common errors gracefully:
- Network timeouts (10-second timeout)
- Invalid JSON responses
- Missing fields in response data
- Cache read/write errors

If an error occurs, the function returns an empty list and prints an error message.
